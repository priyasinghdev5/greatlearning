
import time
import paho.mqtt.client as mqtt

HOST = "localhost"
PORT = 1883     
WAIT_TIME = 0.25  


class EdgeServer:

    def __init__(self, instance_name):
        
        self._instance_id = instance_name
        self.client = mqtt.Client(self._instance_id)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.connect(HOST, PORT, keepalive=60)
        self.client.loop_start()
        self._registered_list = []
        self._command_id = 0

    # Terminating the MQTT broker and stopping the execution
    def terminate(self):
        print("\n")
        self.client.publish(f"/disconnect")
        time.sleep(WAIT_TIME)
        time.sleep(WAIT_TIME)
        self.client.disconnect()
        self.client.loop_stop()
        print("\nSmart Home Simulation stopped.")

    # Connect method to subscribe to various topics.     
    def _on_connect(self, client, userdata, flags, result_code):
        self.client.subscribe("#")
        # pass
        
    # method to process the received messages and publish them on relevant topics
    # this method can also be used to take the action based on received commands
    def _on_message(self, client, userdata, msg):
        # pass
        topic = msg.topic
        device_id = topic.split("/")[0]
        device_type = topic.split("/")[1]
        payload = msg.payload.decode()
        if topic.endswith("/register"):
            print("Request is processed for {}.".format(device_id))
            room_type, switch, temperature = payload.split(":")
            self._registered_list.append(
                {"id": device_id, "room": room_type, "device": device_type,
                 "switch_status": switch, "temperature": temperature})
            self.client.publish(f"{device_id}/{device_type}/registered", True)
        elif topic.endswith("/intensity"):
            device_id = topic.split("/")[0]
            device = next((d for d in self._registered_list if d["id"] == device_id), None)
            switch_stat, light_intensity = payload.split(":")
            if device:
                device["light_intensity"] = light_intensity
                device["switch_status"] = switch_stat
                print(f"\nHere is the current device-status for {device['id']}: {{'device_id': {device['id']}, "
                      f"'switch_state': {device['switch_status']}, 'intensity': {device['light_intensity']}}}")
            else:
                print(f"Unknown device {device_id}")
        elif topic.endswith("/temperature"):
            device_id = topic.split("/")[0]
            device = next((d for d in self._registered_list if d["id"] == device_id), None)
            switch_stat, temp = payload.split(":")
            if device:
                device["temperature"] = temp
                device["switch_status"] = switch_stat
                print(f"\nHere is the current device-status for {device['id']}: {{'device_id': {device['id']}, "
                      f"'switch_state': {device['switch_status']}, 'temperature': {device['temperature']}}}")
            else:
                print(f"Unknown device {device_id}")

    # Returning the current registered list
    def get_registered_device_list(self):
        print("The Registered devices on Edge-Server:")
        # return self._register_list
        # return self._register_list
        return [d["id"] for d in self._registered_list]

    # Getting the status for the connected devices
    def get_status_device_id(self, device_id):
        device = next((d for d in self._registered_list if d["id"] == device_id), None)
        if device:
            self._command_id = self._command_id + 1
            print("\nStatus based on device_id")
            print(f"\nCommand ID {self._command_id} request is initiated.")
            if device["device"] == "AC":
                print(f"\nHere is the current device-status for {device['id']}: {{'device_id': {device['id']}, "
                      f"'switch_state': {device['switch_status']}, 'temperature': {device['temperature']}}}")
                print(f"\nCommand ID {self._command_id} is executed.")
            elif device["device"] == "LIGHT":
                print(f"\nHere is the current device-status for {device['id']}: {{'device_id': {device['id']}, "
                      f"'switch_state': {device['switch_status']}, 'intensity': {device['light_intensity']}}}")
                print(f"\nCommand ID {self._command_id} is executed.")

    # Getting the status for the connected devices
    def get_status_device_type(self, device_type):
        print("\n******************* GETTING THE STATUS BY DEVICE_TYPE *******************")
        self._command_id = self._command_id + 1
        print(f"\nStatus based on : {device_type} DEVICE TYPE")
        print(f"\nCommand ID {self._command_id} request is initiated.")
        for d in self._registered_list:
            if device_type == "LIGHT" and device_type == d['device']:
                print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']},"
                      f" 'switch_state': {d['switch_status']}, 'intensity': {d['light_intensity']}}}")
            elif device_type == "AC" and device_type == d['device']:
                print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']}, "
                      f"'switch_state': {d['switch_status']}, 'temperature': {d['temperature']}}}")
        print(f"\nCommand ID {self._command_id} is executed.")

    # Getting the status for the connected devices
    def get_status_room_type(self, room_type):
        print("\n******************* GETTING THE STATUS BY ROOM_TYPE ******************")
        self._command_id = self._command_id + 1
        print(f"\nStatus based on room: {room_type}")
        print(f"\nCommand ID {self._command_id} request is initiated.")
        for d in self._registered_list:
            room = d["room"]
            if room == room_type:
                if d["device"] == "AC":
                    print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']}, "
                          f"'switch_state': {d['switch_status']}, 'temperature': {d['temperature']}}}")
                elif d["device"] == "LIGHT":
                    print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']}, "
                          f"'switch_state': {d['switch_status']}, 'intensity': {d['light_intensity']}}}")
        print(f"\nCommand ID {self._command_id} is executed.")

    # Getting the status for the connected devices
    def get_status_entire_home(self):
        print("\n******************* GETTING THE STATUS BY ENTIRE_HOME *******************")
        self._command_id = self._command_id + 1
        print(f"\nStatus based on entire home")
        print(f"\nCommand ID {self._command_id} request is initiated.")
        for d in self._registered_list:
            if d["device"] == "AC":
                print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']}, "
                      f"'switch_state': {d['switch_status']}, 'temperature': {d['temperature']}}}")
            elif d["device"] == "LIGHT":
                print(f"\nHere is the current device-status for {d['id']}: {{'device_id': {d['id']}, "
                      f"'switch_state': {d['switch_status']}, 'intensity': {d['light_intensity']}}}")
        print(f"\nCommand ID {self._command_id} is executed.")

    # Controlling and performing the operations on the devices
    # based on the request received
    # Setting the status for the connected devices
    def set_status_device_id(self, device_id, status, device_property):
        device = next((d for d in self._registered_list if d["id"] == device_id), None)
        self._command_id = self._command_id + 1
        print(f"\nControlling the devices based on ID: {device_id}")
        print(f"\nCommand ID {self._command_id} request is initiated.")

        if device:
            self.client.publish(f"{device_id}/{device['device']}/setProperties",
                                f"{status}:{device_property}")
            time.sleep(WAIT_TIME)
        else:
            print("\nThis Device is not Registered")

        print(f"\nCommand ID {self._command_id} is executed.")

    def set_status_device_type(self, device_type, status, device_property):
        self._command_id = self._command_id + 1
        print(f"\nControlling the devices based on TYPE: {device_type}")
        print(f"\nCommand ID {self._command_id} request is initiated.")
        for d in self._registered_list:
            if device_type == d['device']:
                self.client.publish(f"{d['id']}/{d['device']}/setProperties",
                                    f"{status}:{device_property}")
            time.sleep(WAIT_TIME)
        print(f"\nCommand ID {self._command_id} is executed.")

    def set_status_room_type(self, room_type, status, temperature, intensity):
        self._command_id = self._command_id + 1
        print(f"\nControlling the devices based on Room: {room_type}")
        print(f"\nCommand ID {self._command_id} request is initiated.")
        for d in self._registered_list:
            if room_type == "ALL":
                self._set_status_room(d, status, temperature, intensity)
            elif room_type == d['room']:
                self._set_status_room(d, status, temperature, intensity)
        print(f"\nCommand ID {self._command_id} is executed.")

    def _set_status_room(self, device, status, temperature, intensity):
        if device['device'] == "AC":
            self.client.publish(f"{device['id']}/{device['device']}/setProperties",
                                f"{status}:{temperature}")
            time.sleep(WAIT_TIME)
        elif device['device'] == "LIGHT":
            self.client.publish(f"{device['id']}/{device['device']}/setProperties",
                                f"{status}:{intensity}")
            time.sleep(WAIT_TIME)

