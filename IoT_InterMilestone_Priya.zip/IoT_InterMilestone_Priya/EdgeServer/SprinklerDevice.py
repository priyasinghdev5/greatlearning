import AWSIoTPythonSDK.MQTTLib as AWSIoTPyMQTT

ENDPOINT = "a10nh4xd2yg7uo-ats.iot.us-east-1.amazonaws.com"
PATH_TO_CERT = "config"


# AWS class to create number of objects (devices)
class SprinklerDevice:
    # Constructor that accepts client id that works as device id and file names for different devices
    # This method will obviosuly be called while creating the instance
    # It will create the MQTT client for AWS using the credentials
    # Connect operation will make sure that connection is established between the device and AWS MQTT
    def __init__(self, client, certificate, private_key):

        self.client_id = client
        self.device_id = client
        self._switch_status = "OFF"
        self.cert_path = PATH_TO_CERT + "\\" + certificate + "-certificate.pem.crt"
        self.pvt_key_path = PATH_TO_CERT + "\\" + private_key + "-private.pem.key"
        self.root_path = PATH_TO_CERT + "\\" + "AmazonRootCA1.pem"
        self.myAWSIoTMQTTClient = AWSIoTPyMQTT.AWSIoTMQTTClient(self.client_id)
        self.myAWSIoTMQTTClient.configureEndpoint(ENDPOINT, 8883)
        print(ENDPOINT)
        print(self.root_path)
        print(self.pvt_key_path)
        print(self.cert_path)
        self.myAWSIoTMQTTClient.configureCredentials(self.root_path, self.pvt_key_path, self.cert_path)
        # self.myAWSIoTMQTTClient.on_connect = self._on_connect
        # self.myAWSIoTMQTTClient.on_message = self._on_message

        self.myAWSIoTMQTTClient.subscribe(f"{self.device_id}/SPRINKLER/setStatus", 1, self.on_message)

        # AWSIoTMQTTClient connection configuration
        self.myAWSIoTMQTTClient.configureAutoReconnectBackoffTime(1, 32, 20)
        self.myAWSIoTMQTTClient.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
        self.myAWSIoTMQTTClient.configureDrainingFrequency(2)  # Draining: 2 Hz
        self.myAWSIoTMQTTClient.configureConnectDisconnectTimeout(20)  # 10 sec
        self.myAWSIoTMQTTClient.configureMQTTOperationTimeout(20)  # 5 sec

        self._connect()

    # Connect method to establish connection with AWS IoT core MQTT
    def _connect(self):
        self.myAWSIoTMQTTClient.connect()

    # Connect method to subscribe to various topics.
    # def _on_connect(self, client, userdata, flags, rc):
    #     print("On Connect")
    #     if rc == 0:
    #         self.myAWSIoTMQTTClient.subscribe(f"{self.device_id}/SPRINKLER/setStatus")
    #         self.myAWSIoTMQTTClient.subscribe("/disconnect")
    #     else:
    #         print("\nClient Connection failed. rc= " + str(rc))

    def on_message(self, client, userdata, msg):
        print("on message")
        topic = msg.topic
        payload = msg.payload.decode()
        if topic.endswith(f"{self.device_id}/SPRINKLER/setStatus"):
            status = payload
            self._switch_status = status
            # Set status in DB for sprinkler
            print("Set status in DB for sprinkler")
        elif topic.endswith("/disconnect"):
            self.myAWSIoTMQTTClient.disconnect()

    # Disconect operation for each devices
    def disconnect(self):
        self.myAWSIoTMQTTClient.disconnect()
