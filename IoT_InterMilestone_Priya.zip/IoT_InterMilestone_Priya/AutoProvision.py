import subprocess
import json
import boto3
from src.Database import Database
from datetime import datetime
from EdgeServer.EdgeServer import EdgeServer
import time


def configure_aws_cli():
    with open("resource/aws_access.json", 'r') as file:
        aws_access = file.read()

    access = json.loads(aws_access)
    print(f"out_json ---- {access}")
    try:
        # Configure AWS CLI options individually
        subprocess.run(["aws", "configure", "set", "aws_access_key_id", access.get("aws_access_key_id")], check=True)
        subprocess.run(["aws", "configure", "set", "aws_secret_access_key", access.get("aws_secret_access_key")], check=True)
        subprocess.run(["aws", "configure", "set", "region", access.get("aws_default_region")], check=True)
        print("AWS CLI configured successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error configuring AWS CLI: {e}")
        print(f"Command output: {e.output}")


def create_iot_thing(thing_name, thing_type_name):
    print(f"create_iot_thing")
    try:
        # Construct the AWS CLI command to create an IoT thing
        aws_command = [
            "aws",
            "iot",
            "create-thing",
            "--thing-name", thing_name,
            "--thing-type-name", thing_type_name
        ]

        print(f"aws_command: {aws_command}")
        # Run the AWS CLI command
        result = subprocess.run(aws_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        print(f"result: {result}")

        # Parse the JSON output
        output_json = json.loads(result.stdout)
        # return output_json

        # Extract and return the thing ARN
        thing_arn = output_json.get("thingArn")
        return thing_arn
    except subprocess.CalledProcessError as e:
        print(f"Error creating IoT thing: {e}")
        print(f"Command output: {e.output}")
        return None


def create_keys_and_certificate():
    print(f"create_keys_and_certificate")
    try:
        # Construct the AWS CLI command to create keys and certificate
        aws_command = [
            "aws",
            "iot",
            "create-keys-and-certificate",
            "--set-as-active"
        ]

        print(f"aws_command - {aws_command}")

        # Run the AWS CLI command
        result = subprocess.run(aws_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        # Parse the JSON output
        output_json = json.loads(result.stdout)

        print(f"output_json - {output_json}")
        # Extract and return certificate ARN, certificate PEM, and private key PEM
        cert_arn = output_json.get("certificateArn")
        cert_pem = output_json.get("certificatePem")
        key_pem = output_json.get("keyPair")
        print(f"keyPair: {key_pem}")
        private_pem = key_pem.get("PrivateKey")
        print(f"private_pem: {private_pem}")

        return cert_arn, cert_pem, private_pem
    except subprocess.CalledProcessError as e:
        print(f"Error creating keys and certificate: {e}")
        print(f"Command output: {e.output}")
        return None, None, None


def attach_thing_principal(thing_name, cert_arn):
    print(f"attach_thing_principal")
    try:
        # Construct the AWS CLI command to attach thing principal
        aws_command = [
            "aws",
            "iot",
            "attach-thing-principal",
            "--thing-name", thing_name,
            "--principal", cert_arn
        ]

        print(f"aws_command - {aws_command}")

        # Run the AWS CLI command
        subprocess.run(aws_command, check=True)
        print("Thing principal attached successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error attaching thing principal: {e}")
        print(f"Command output: {e.output}")


def attach_policy(policy_name, thing_arn_sensor):
    try:
        # Construct the AWS CLI command to create an IoT policy
        aws_command = [
            "aws",
            "iot",
            "attach-policy",
            "--policy-name", policy_name,
            "--target", thing_arn_sensor
        ]

        # Run the AWS CLI command
        subprocess.run(aws_command, check=True)
        print("Thing policy attached successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error attaching thing policy: {e}")
        print(f"Command output: {e.output}")


def save_to_file(file_path, content):
    with open(file_path, 'w') as file:
        file.write(content)


def create_sensor_table():
    # Get the service resource.
    dynamodb = boto3.resource('dynamodb')

    # Get Database class methods to create table
    dynamodb = Database(dynamodb)

    # Check if database already exists or not
    db_exists = dynamodb.exists('sensor_raw_data')

    # If database doesn't exist call create table method
    if not db_exists:
        print("\nCreating table sensor_data...")
        dynamodb.create_sprinkler_table('sensor_raw_data')
        print("\nCreated table sensor_data.")


def create_sprinkler_table():
    # Get the service resource.
    dynamodb = boto3.resource('dynamodb')

    # Get Database class methods to create table
    dynamodb = Database(dynamodb)

    # Check if database already exists or not
    db_exists = dynamodb.exists('sprinkler_data')

    # If database doesn't exist call create table method
    if not db_exists:
        print("\nCreating table sprinkler_data...")
        dynamodb.create_sprinkler_table('sprinkler_data')
        print("\nCreated table sprinkler_data.")


def create_certificate_and_attach_principal(thing, thing_arn, policy_name):
    if thing_arn:
        print(f"IoT Thing created successfully with ARN: {thing_arn}")

        # Create keys and certificate
        cert_arn, cert_pem, key_pem = create_keys_and_certificate()

        if cert_arn and cert_pem and key_pem:
            print(f"Certificate ARN: {cert_arn}")
            print("Certificate PEM:")
            print(cert_pem)
            print("Private Key PEM:")
            print(key_pem)

            # Save certificate PEM to a file
            cert_file_path = f"config/{thing}-certificate.pem.crt"
            save_to_file(cert_file_path, cert_pem)
            print(f"Certificate PEM saved to {cert_file_path}")

            # Save private key PEM to a file
            key_file_path = f"config/{thing}-private.pem.key"
            save_to_file(key_file_path, key_pem)
            print(f"Private Key PEM saved to {key_file_path}")

            # Attach thing principal
            attach_thing_principal(thing, cert_arn)

            # Attach thing policy
            attach_policy(policy_name, cert_arn)


def add_data_mapping_to_sprinkler_table(sprinkler, sensors):

    # Get the service resource.
    dynamodb = boto3.resource('dynamodb')

    # Get table from dynamoDB
    sprinkler_table = dynamodb.Table('sprinkler_data')

    item = {'deviceid': sprinkler,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'mapped_sensor': sensors,
            'status': 'OFF',
            }

    sprinkler_table.put_item(Item=item)


def create_thing_type(thing_type_name, thing_type_description):
    print(thing_type_description)
    try:
        # Construct the AWS CLI command to create an IoT Thing Type
        aws_command = [
            "aws",
            "iot",
            "create-thing-type",
            "--thing-type-name", thing_type_name
        ]

        # Run the AWS CLI command
        subprocess.run(aws_command, check=True)
        print(f"IoT Thing Type '{thing_type_name}' created successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error creating IoT Thing Type: {e}")
        print(f"Command output: {e.output}")


def create_iot_policy(policy_name, policy_document):
    try:
        # Construct the AWS CLI command to create an IoT policy
        aws_command = [
            "aws",
            "iot",
            "create-policy",
            "--policy-name", policy_name,
            "--policy-document", policy_document
        ]

        # Run the AWS CLI command
        subprocess.run(aws_command, check=True)
        print(f"IoT Policy '{policy_name}' created successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error creating IoT Policy: {e}")
        print(f"Command output: {e.output}")


def auto_provision():
    # Configure AWS CLI
    configure_aws_cli()

    with open("resource/InitiateThing.json", 'r') as file:
        thing_mapping_file = file.read()

    print(f"things ---- {thing_mapping_file}")
    out_json = json.loads(thing_mapping_file)

    # Dynamo Db creation and mapping insert
    create_sensor_table()

    # Dynamo Db creation and mapping insert
    create_sprinkler_table()

    for thing_type in ("Sensors", "Sprinklers"):
        create_thing_type(thing_type, "Thing type : "+thing_type)

    policy_name = "IOT_Sensor_Policy"
    policy_document = '{"Version": "2012-10-17","Statement": [{"Effect": "Allow","Action": "*","Resource": "*"}]}'
    create_iot_policy(policy_name, policy_document)

    for key, value in out_json.items():
        print(key, value)
        # create sprinkler thing
        thing_arn_sprinkler = create_iot_thing(key, "Sprinklers")
        create_certificate_and_attach_principal(key, thing_arn_sprinkler, policy_name)
        for sensor_thing in value:
            print(sensor_thing)
            # create sensor thing
            thing_arn_sensor = create_iot_thing(sensor_thing, "Sensors")
            create_certificate_and_attach_principal(sensor_thing, thing_arn_sensor, policy_name)
        add_data_mapping_to_sprinkler_table(key, value)


auto_provision()

