"""
Purpose

We will use AWS SDK for Python (Boto3) with Amazon DynamoDB to
create and use a table that stores data about devices.

This file contains method to create, delete, check existing table and provide list of tables
"""

import logging
from botocore.exceptions import ClientError

logger = logging.getLogger()


# start:[Database.class_full]
# start:[Database.class_declaration]
class Database:
    """Encapsulates an AWS DynamoDB table"""
    def __init__(self, dynamo_resource):
        """
        :param dynamo_resource: A Boto3 DynamoDB resource.
        """
        self.dynamo_resource = dynamo_resource
        self.table = None
# end:[Database.class_declaration]

    # start:[code.dynamodb.DescribeTable]
    def exists(self, table_name):
        """
        Determines whether a table exists. As a side effect.

        :param table_name: The name of the table to check.
        :return: True when the table exists; otherwise, False.
        """
        try:
            table = self.dynamo_resource.Table(table_name)
            table.load()
            exists = True
        except ClientError as err:
            if err.response['Error']['Code'] == 'ResourceNotFoundException':
                exists = False
            else:
                logger.error(
                    "Couldn't check for existence of %s. Here's why: %s: %s",
                    table_name,
                    err.response['Error']['Code'], err.response['Error']['Message'])
                raise
        else:
            self.table = table
        return exists
    # end:[code.dynamodb.DescribeTable]

    # start:[code.dynamodb.create_agg_table]
    def create_sprinkler_table(self, table_name):
        """
        Creates an Amazon DynamoDB table that can be used to store movie data.
        The table uses the deviceid as the partition key and the timestamp as
        the sort key.

        :param table_name: The name of the table to create.
        :return: The newly created table.
        """
        try:
            self.table = self.dynamo_resource.create_table(
                TableName=table_name,
                KeySchema=[
                    {'AttributeName': 'deviceid', 'KeyType': 'HASH'},  # Partition key
                    {'AttributeName': 'timestamp', 'KeyType': 'RANGE'}  # Sort key
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'deviceid', 'AttributeType': 'S'},
                    {'AttributeName': 'timestamp', 'AttributeType': 'S'}
                ],
                ProvisionedThroughput={'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5})
            self.table.wait_until_exists()
        except ClientError as err:
            logger.error(
                "Couldn't create table %s. Here's why: %s: %s", table_name,
                err.response['Error']['Code'], err.response['Error']['Message'])
            raise
        else:
            return self.table
    # end:[code.dynamodb.create_agg_table]

    # start:[code.dynamodb.ListTables]
    def list_tables(self):
        """
        Lists the Amazon DynamoDB tables for the current account.

        :return: The list of tables.
        """
        try:
            tables = []
            for table in self.dynamo_resource.tables.all():
                print(table.name)
                tables.append(table)
        except ClientError as err:
            logger.error(
                "Couldn't list tables. Here's why: %s: %s",
                err.response['Error']['Code'], err.response['Error']['Message'])
            raise
        else:
            return tables
    # end:[code.dynamodb.ListTables]

    # start:[code.dynamodb.DeleteTable]
    def delete_table(self):
        """
        Deletes the table.
        """
        try:
            self.table.delete()
            self.table = None
        except ClientError as err:
            logger.error(
                "Couldn't delete table. Here's why: %s: %s",
                err.response['Error']['Code'], err.response['Error']['Message'])
            raise
    # end:[code.dynamodb.DeleteTable]
# end:[Database.class_full]
