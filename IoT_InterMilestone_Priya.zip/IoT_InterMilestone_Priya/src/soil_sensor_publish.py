import time
import json
import AWSIoTPythonSDK.MQTTLib as AWSIoTPyMQTT
from src import WeatherApiDataIngestion as weatherApiDataIngestion
import random
import datetime
import sched
import time
import os

# Define ENDPOINT, TOPIC, RELATOVE DIRECTORY for CERTIFICATE AND KEYS
ENDPOINT = "a10nh4xd2yg7uo-ats.iot.us-east-1.amazonaws.com"
PATH_TO_CERT = "config"
SENSOR_TOPIC = "iot/agritech/sensor"
# SPRINKLER_TOPIC = "iot/agritech/sprinkler"


# AWS class to create number of objects (devices)
class AWS():
    # Constructor that accepts client id that works as device id and file names for different devices
    # This method will obviosuly be called while creating the instance
    # It will create the MQTT client for AWS using the credentials
    # Connect operation will make sure that connection is established between the device and AWS MQTT
    def __init__(self, client, certificate, private_key):

        self.client_id = client
        self.device_id = client
        self.cert_path = PATH_TO_CERT + "\\" + certificate + "-certificate.pem.crt"
        self.pvt_key_path = PATH_TO_CERT + "\\" + private_key + "-private.pem.key"
        self.root_path = PATH_TO_CERT + "\\" + "AmazonRootCA1.pem"
        self.myAWSIoTMQTTClient = AWSIoTPyMQTT.AWSIoTMQTTClient(self.client_id)
        self.myAWSIoTMQTTClient.configureEndpoint(ENDPOINT, 8883)
        print(ENDPOINT)
        print(self.root_path)
        print(self.pvt_key_path)
        print(self.cert_path)
        self.myAWSIoTMQTTClient.configureCredentials(self.root_path, self.pvt_key_path, self.cert_path)

        # AWSIoTMQTTClient connection configuration
        self.myAWSIoTMQTTClient.configureAutoReconnectBackoffTime(1, 32, 20)
        self.myAWSIoTMQTTClient.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
        self.myAWSIoTMQTTClient.configureDrainingFrequency(2)  # Draining: 2 Hz
        self.myAWSIoTMQTTClient.configureConnectDisconnectTimeout(20)  # 10 sec
        self.myAWSIoTMQTTClient.configureMQTTOperationTimeout(20)  # 5 sec

        self._connect()

    # Connect method to establish connection with AWS IoT core MQTT
    def _connect(self):
        self.myAWSIoTMQTTClient.connect()

    # This method will publish the data on MQTT 
    # Before publishing we are confiuguring message to be published on MQTT
    def publish_sensor(self, air_humidity, air_temperature, latitude, longitude):
        print('Begin Publish')

        # for i in range(10):
        message = {}
        value = float(random.normalvariate(99, 1.5))
        soilTemperature = round(value, 1)

        soilMoisture = int(random.normalvariate(45, 10.0))

        timestamp = str(datetime.datetime.now())
        message['deviceid'] = self.device_id
        message['timestamp'] = timestamp

        message['soilTemperature'] = soilTemperature
        message['soilMoisture'] = soilMoisture
        message['airTemperature'] = air_temperature
        message['airHumidity'] = air_humidity
        message['latitude'] = latitude
        message['longitude'] = longitude
        # message['sprinklerId'] = self.sprinkler_id

        messageJson = json.dumps(message)
        self.myAWSIoTMQTTClient.publish(SENSOR_TOPIC, messageJson, 1)
        print("Published: '" + json.dumps(message) + "' to the topic: " + SENSOR_TOPIC)
        time.sleep(0.1)
        print('Publish End')

    # def publish_sprinkler(self, mapped_sensor):
    #     print('Begin Publish')
    #
    #     # for i in range(10):
    #     message = {}
    #
    #     timestamp = str(datetime.datetime.now())
    #     message['deviceid'] = self.device_id
    #     message['timestamp'] = timestamp
    #     message['status'] = "OFF"
    #     message['mapped_sensor'] = mapped_sensor
    #
    #     messageJson = json.dumps(message)
    #     self.myAWSIoTMQTTClient.publish(SPRINKLER_TOPIC, messageJson, 1)
    #     print("Published: '" + json.dumps(message) + "' to the topic: " + SPRINKLER_TOPIC)
    #     time.sleep(0.1)
    #     print('Publish End')

    # Disconect operation for each devices
    def disconnect(self):
        self.myAWSIoTMQTTClient.disconnect()


def push_sensor_data(latitude, longitude):

    # Soil sensor device Objects
    # soil_sensor_1 = AWS("soil_sensor_1", "soil_sensor_1", "soil_sensor_1")
    # soil_sensor_2 = AWS("soil_sensor_2", "soil_sensor_2", "soil_sensor_2")
    # soil_sensor_3 = AWS("soil_sensor_3", "soil_sensor_3", "soil_sensor_3")
    # soil_sensor_4 = AWS("soil_sensor_4", "soil_sensor_4", "soil_sensor_4")
    #
    # soil_sensor_5 = AWS("soil_sensor_5", "soil_sensor_5", "soil_sensor_5")
    # soil_sensor_6 = AWS("soil_sensor_6", "soil_sensor_6", "soil_sensor_6")
    # soil_sensor_7 = AWS("soil_sensor_7", "soil_sensor_7", "soil_sensor_7")
    # soil_sensor_8 = AWS("soil_sensor_8", "soil_sensor_8", "soil_sensor_8")
    #
    # soil_sensor_9 = AWS("soil_sensor_9", "soil_sensor_9", "soil_sensor_9")
    # soil_sensor_10 = AWS("soil_sensor_10", "soil_sensor_10", "soil_sensor_10")
    # soil_sensor_11 = AWS("soil_sensor_11", "soil_sensor_11", "soil_sensor_11")
    # soil_sensor_12 = AWS("soil_sensor_12", "soil_sensor_12", "soil_sensor_12")
    #
    # soil_sensor_13 = AWS("soil_sensor_13", "soil_sensor_13", "soil_sensor_13")
    # soil_sensor_14 = AWS("soil_sensor_14", "soil_sensor_14", "soil_sensor_14")
    # soil_sensor_15 = AWS("soil_sensor_15", "soil_sensor_15", "soil_sensor_15")
    # soil_sensor_16 = AWS("soil_sensor_16", "soil_sensor_16", "soil_sensor_16")
    #
    # soil_sensor_17 = AWS("soil_sensor_17", "soil_sensor_17", "soil_sensor_17")
    # soil_sensor_18 = AWS("soil_sensor_18", "soil_sensor_18", "soil_sensor_18")
    # soil_sensor_19 = AWS("soil_sensor_19", "soil_sensor_19", "soil_sensor_19")
    # soil_sensor_20 = AWS("soil_sensor_20", "soil_sensor_20", "soil_sensor_20")

    # Initialize Sprinkler device
    # sprinkler_1 = AWS("sprinkler_1", "sprinkler_1", "sprinkler_1")
    # sprinkler_2 = AWS("sprinkler_2", "sprinkler_2", "sprinkler_2")
    # sprinkler_3 = AWS("sprinkler_3", "sprinkler_3", "sprinkler_3")
    # sprinkler_4 = AWS("sprinkler_4", "sprinkler_4", "sprinkler_4")
    # sprinkler_5 = AWS("sprinkler_5", "sprinkler_5", "sprinkler_5")

    # Mapping sensors to sprinklers
    # device_mapping = {sprinkler_1: ["soil_sensor_1", "soil_sensor_2", "soil_sensor_3", "soil_sensor_4"],
    #                   sprinkler_2: ["soil_sensor_5", "soil_sensor_6", "soil_sensor_7", "soil_sensor_8"],
    #                   sprinkler_3: ["soil_sensor_9", "soil_sensor_10", "soil_sensor_11", "soil_sensor_12"],
    #                   sprinkler_4: ["soil_sensor_13", "soil_sensor_14", "soil_sensor_15", "soil_sensor_16"],
    #                   sprinkler_5: ["soil_sensor_17", "soil_sensor_18", "soil_sensor_19", "soil_sensor_20"]}
    #
    # for key, value in device_mapping.items():
    #     key.publish_sprinkler(value)

    with open("resource/InitiateThing.json", 'r') as file:
        thing_mapping_file = file.read()

    print(f"things ---- {thing_mapping_file}")
    out_json = json.loads(thing_mapping_file)

    sensors = []
    for key, value in out_json.items():
        for sensor_thing in value:
            print(sensor_thing)
            sensors.append(sensor_thing)

    while True:
        try:
            airHumidity, airTemperature = weatherApiDataIngestion.get_weather_api_data(latitude, longitude)
            print("sensor call")
            # for sensor in (soil_sensor_1, soil_sensor_2, soil_sensor_3, soil_sensor_4, soil_sensor_5,
            #                soil_sensor_6, soil_sensor_7, soil_sensor_8, soil_sensor_9, soil_sensor_10,
            #                soil_sensor_11, soil_sensor_12, soil_sensor_13, soil_sensor_14, soil_sensor_15,
            #                soil_sensor_16, soil_sensor_17, soil_sensor_18, soil_sensor_19, soil_sensor_20):
            #     sensor.publish_sensor(airHumidity, airTemperature, latitude, longitude)

            for sensor in sensors:
                sensor_object = AWS(sensor, sensor, sensor)
                sensor_object.publish_sensor(airHumidity, airTemperature, latitude, longitude)

            time.sleep(2)
        except KeyboardInterrupt:
            break
