import boto3
import json
import base64
import decimal
from datetime import datetime

dynamodb_res = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb_res.Table('stockfinancedb')
sns = boto3.client('sns', region_name='us-east-1')
topic_arn = 'arn:aws:sns:us-east-1:735515345209:stockPOIAlert'


def lambda_handler(event, context):
    if 'Records' in event:
        # Handle Kinesis event payload with 'Records' field
        records = event['Records']
        for record in records:
            if 'kinesis' in record:
                kinesis_data = record['kinesis']
                data = base64.b64decode(kinesis_data['data']).decode('utf-8')
                item = json.loads(data, parse_float=decimal.Decimal)
                stock_id = item['stockid']
                postMarketPrice = item['postMarketPrice']
                timestamp = item['timestamp']
                fifty_two_week_high = item['52WeekHigh']
                fifty_two_week_low = item['52WeekLow']

                boolpoiflag, case = validate_poi(postMarketPrice, fifty_two_week_high, fifty_two_week_low)

                if boolpoiflag and check_existing_data(stock_id, timestamp):
                    # Prepare the item for DynamoDB
                    dynamodb_item = {
                        'stockid': stock_id,
                        'postMarketPrice': postMarketPrice,
                        'timestamp': timestamp,
                        '52WeekHigh': fifty_two_week_high,
                        '52WeekLow': fifty_two_week_low
                    }

                    # Insert the item into DynamoDB
                    response = table.put_item(Item=dynamodb_item)
                    print('DynamoDB response:', response)

                    # Publish the decoded data to SNS
                    sns.publish(
                        TopicArn=topic_arn,
                        Message=f"{stock_id} Stock post market price : {postMarketPrice} has crossed POI(point of interest) threshold of {case} on {timestamp}",
                        Subject=f"{stock_id} | POI threshold crossed | {timestamp}"
                    )

    else:
        # Handle event payload without 'Records' field
        if 'stockid' in event:
            stock_id = event['stockid']
            postMarketPrice = event['postMarketPrice']
            timestamp = event['timestamp']
            fifty_two_week_high = event['52WeekHigh']
            fifty_two_week_low = event['52WeekLow']

            boolpoiflag, case = validate_poi(postMarketPrice, fifty_two_week_high, fifty_two_week_low)
            print(boolpoiflag)
            print(case)

            if boolpoiflag and check_existing_data(stock_id, timestamp):
                # Prepare the item for DynamoDB
                dynamodb_item = {
                    'stockid': stock_id,
                    'postMarketPrice': decimal.Decimal(str(postMarketPrice)),
                    'timestamp': timestamp,
                    '52WeekHigh': decimal.Decimal(str(fifty_two_week_high)),
                    '52WeekLow': decimal.Decimal(str(fifty_two_week_low))
                }

                # Insert the item into DynamoDB
                response = table.put_item(Item=dynamodb_item)
                print('DynamoDB response:', response)

                # Publish the decoded data to SNS
                sns.publish(
                    TopicArn=topic_arn,
                    Message=f"{stock_id} Stock post market price : {postMarketPrice} has crossed POI(point of interest) threshold of {case} on {timestamp}",
                    Subject=f"{stock_id} | POI threshold crossed | {timestamp}"
                )

    return {
        'statusCode': 200,
        'body': 'Data inserted into DynamoDB'
    }


# Validating point of interest data
def validate_poi(post_market_price, fifty_two_week_high, fifty_two_week_low):
    if post_market_price >= (0.8 * float(fifty_two_week_high)):
        return True, 'fifty_two_week_high'
    elif post_market_price <= (1.2 * float(fifty_two_week_low)):
        return True, 'fifty_two_week_low'
    else:
        return False, ''


# Check already existing data in dynamodb
def check_existing_data(stock_id, stock_timestamp):
    dynamodb = boto3.client('dynamodb')

    # Convert the incoming date string to a datetime object
    incoming_date = datetime.strptime(stock_timestamp, '%Y-%m-%d %H:%M:%S')

    # Extract the date portion
    today = incoming_date.date()

    response = dynamodb.query(
        TableName='stockfinancedb',
        KeyConditionExpression='stockid = :partition_value AND begins_with(#ts, :sort_value)',
        ExpressionAttributeValues={
            ':partition_value': {'S': stock_id},
            ':sort_value': {'S': today.isoformat()}
        },
        ExpressionAttributeNames={
            '#ts': 'timestamp'
        }
    )

    if len(response['Items']) > 0:
        print("Data exists.")
        return False
    else:
        print("No data found.")
        return True


