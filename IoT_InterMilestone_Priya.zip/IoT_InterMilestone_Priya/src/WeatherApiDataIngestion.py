from pyowm import OWM
import json
import boto3
import datetime

kinesis = boto3.client('kinesis', region_name="us-east-1")

end_date = datetime.date.today()
start_date = end_date - datetime.timedelta(days=2)


def get_weather_api_data(latitude, longitude):
    owm = OWM('0f8b321c68552dff33eeb5625f971c39')
    mgr = owm.weather_manager()
    one_call = mgr.one_call(lat=latitude, lon=longitude)
    current_data = json.dumps(one_call.current.__dict__)
    # info = current_data.info
    # print(f"Weather Data for given lat and long: {info}")
    print(f"Weather Data for given lat and long: {current_data}")

    humidity = extract_key_value(current_data, "humidity")
    temp = json.dumps(extract_key_value(current_data, "temp"))
    temp = extract_key_value(temp, "temp")

    return humidity, temp


def extract_key_value(json_data, key):
    """Extracts a specific key-value pair from a JSON data"""
    data = json.loads(json_data)
    value = data.get(key)
    return value
