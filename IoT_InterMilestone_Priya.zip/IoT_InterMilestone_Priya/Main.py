import AutoProvision
from src import soil_sensor_publish
import sched
import time
import argparse


# Read in command-line parameters
parser = argparse.ArgumentParser()
parser.add_argument("-f", "--farm", action="store", required=True, dest="farm", help="Farm Name")
parser.add_argument("-la", "--latitude", action="store", type=float, required=True, dest="latitude", help="Farm Latitude")
parser.add_argument("-lo", "--longitude", action="store", type=float, required=True, dest="longitude", help="Farm Longitude")

args = parser.parse_args()
farm = args.farm
print(farm)
latitude = args.latitude
print(latitude)
longitude = args.longitude
print(longitude)

scheduler = sched.scheduler(time.time, time.sleep)
now = time.time()
loopCount = 0

# while True:
#     try:
#         # if args.mode == 'both' or args.mode == 'publish':
#         airHumidity, airTemperature = weatherApiDataIngestion.get_weather_api_data(latitude, longitude)
#         scheduler.enterabs(now + loopCount, 1, soil_sensor_publish.push_sensor_data,
#                            (loopCount, airHumidity, airTemperature, latitude, longitude))
#         loopCount += 1
#         scheduler.run()
#     except KeyboardInterrupt:
#         break

# Auto Provisioning
# AutoProvision.auto_provision()

# airHumidity, airTemperature = weatherApiDataIngestion.get_weather_api_data(latitude, longitude)
soil_sensor_publish.push_sensor_data(latitude, longitude)
